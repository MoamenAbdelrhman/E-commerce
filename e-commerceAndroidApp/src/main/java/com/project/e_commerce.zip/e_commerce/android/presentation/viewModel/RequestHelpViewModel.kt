package com.project.e_commerce.android.presentation.viewModel

import androidx.lifecycle.viewModelScope
import androidx.navigation.NavController
import com.project.e_commerce.android.presentation.ui.screens.requestHelpScreen.RequestHelpUIState
import com.project.e_commerce.android.presentation.viewModel.baseViewModel.BaseViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class RequestHelpViewModel: BaseViewModel() {

    private val _state = MutableStateFlow(RequestHelpUIState())
    val state = _state.asStateFlow()

    fun onWriteSubject(subjectMessage: String){
        val copyState = _state.value.copy(
            subjectMessage = subjectMessage
        )
        viewModelScope.launch {
            _state.emit(copyState)
        }
    }

    fun onWriteBodyMessage(subjectBody: String){
        val copyState = _state.value.copy(
            bodyMessage = subjectBody
        )
        viewModelScope.launch {
            _state.emit(copyState)
        }
    }

    fun onClickTheSendButton(navController: NavController){

    }

    override fun setLoadingState(loadingState: Boolean) {
        val copyState = _state.value.copy(
            isLoading = loadingState
        )
        viewModelScope.launch {
            _state.emit(copyState)
        }
    }

    override fun setErrorState(errorState: Boolean, errorMessage: String) {
        val copyState = _state.value.copy(
            isError = errorState,
            errorMessage = errorMessage
        )
        viewModelScope.launch {
            _state.emit(copyState)
        }
    }
}