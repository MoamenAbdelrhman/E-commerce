package com.project.e_commerce.android.presentation.ui.screens.onboarding

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Button
import androidx.compose.material.ButtonDefaults
import androidx.compose.material.Card
import androidx.compose.material.Icon
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.project.e_commerce.android.R
import androidx.compose.ui.graphics.Brush

@Composable
fun OnboardingScreen(
    imageRes: Int,
    title: String,
    description: String,
    isFirst: Boolean,
    isLast: Boolean,
    onNextClick: () -> Unit,
    onSkipClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        if (!isLast) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(16.dp)
            ) {
                Button(
                    onClick = onSkipClick,
                    shape = RoundedCornerShape(20.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                    colors = ButtonDefaults.buttonColors(backgroundColor = Color.Transparent),
                    elevation = ButtonDefaults.elevation(0.dp),
                    modifier = Modifier
                        .height(36.dp)
                        .background(
                            brush = Brush.verticalGradient(
                                colors = listOf(Color(0xFF3C8CE7), Color(0xFF00EAFF))
                            ),
                            shape = RoundedCornerShape(20.dp)
                        )
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Skip",
                            color = Color.White,
                            fontSize = 14.sp
                        )
                        Icon(
                            painter = painterResource(id = R.drawable.ic_arrow_forward),
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier
                                .size(16.dp)
                                .padding(start = 4.dp)
                        )
                    }
                }
            }
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 100.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(300.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFF5F6FA))
            ) {
                Image(
                    painter = painterResource(id = imageRes),
                    contentDescription = title,
                    modifier = Modifier
                        .size(250.dp)
                        .align(Alignment.Center)
                )
            }

            Card(
                shape = RoundedCornerShape(topStart = 94.dp, topEnd = 94.dp),
                elevation = 16.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxSize()
                    .padding(top = 32.dp)
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 24.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .padding(bottom = 16.dp, top = 8.dp, start = 16.dp)
                            .align(Alignment.Start),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(30.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFFFA726))
                                .background(
                                    brush = Brush.verticalGradient(
                                        colors = listOf(Color(0xFFFFA8A8), Color(0xFFFCFF00))
                                    )
                                )
                                .padding(start = 8.dp)
                        )
                        Box(
                            modifier = Modifier
                                .size(20.dp)
                                .clip(CircleShape)
                                .background(
                                    brush = Brush.verticalGradient(
                                        colors = listOf(Color(0xFFFFA8A8), Color(0xFFFCFF00))
                                    )
                                )
                        )
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(
                                    brush = Brush.verticalGradient(
                                        colors = listOf(Color(0xFFFFA8A8), Color(0xFFFCFF00))
                                    )
                                )
                                .padding(start = 80.dp)
                        )
                    }
                    Text(
                        text = title,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1A73E8)
                    )
                    Text(
                        text = description,
                        fontSize = 16.sp,
                        color = Color(0xFF6D8299),
                        modifier = Modifier.padding(top = 16.dp)
                    )
                    Button(
                        onClick = onNextClick,
                        colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFFFF5722)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .padding(top = 32.dp)
                            .padding(horizontal = 16.dp)
                            .fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = if (isLast) "Get Started" else "Next", color = Color.White)
                            Icon(
                                painter = painterResource(id = R.drawable.ic_arrow_forward),
                                contentDescription = "Next Arrow",
                                tint = Color.White,
                                modifier = Modifier
                                    .padding(start = 8.dp)
                                    .size(14.dp)
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.padding(top = 24.dp),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        DotIndicator(isActive = isFirst)
                        DotIndicator(isActive = !isFirst && !isLast)
                        DotIndicator(isActive = isLast)
                    }
                }
            }
        }
    }
}

@Composable
fun DotIndicator(isActive: Boolean) {
    Box(
        modifier = Modifier
            .padding(horizontal = 4.dp)
            .size(if (isActive) 12.dp else 8.dp)
            .clip(CircleShape)
            .background(if (isActive) Color(0xFFFF5722) else Color(0xFFCCCCCC))
    )
}

@Preview(showBackground = true)
@Composable
fun OnboardingScreen1Preview() {
    OnboardingScreen1(navController = rememberNavController())
}

@Composable
fun OnboardingScreen1(navController: NavController) {
    OnboardingScreen(
        imageRes = R.drawable.onboarding1_image,
        title = "Discover Amazing Products!",
        description = "Explore thousands of items.",
        isFirst = true,
        isLast = false,
        onNextClick = { navController.navigate("onboarding2") },
        onSkipClick = { navController.navigate("main") }
    )
}

@Preview(showBackground = true)
@Composable
fun OnboardingScreen2Preview() {
    OnboardingScreen2(navController = rememberNavController())
}

@Composable
fun OnboardingScreen2(navController: NavController) {
    OnboardingScreen(
        imageRes = R.drawable.onboarding2_image,
        title = "Safe Payments Fast Delivery",
        description = "Choose from multiple payment methods.",
        isFirst = false,
        isLast = false,
        onNextClick = { navController.navigate("onboarding3") },
        onSkipClick = { navController.navigate("main") }
    )
}

@Preview(showBackground = true)
@Composable
fun OnboardingScreen3Preview() {
    OnboardingScreen3(navController = rememberNavController())
}

@Composable
fun OnboardingScreen3(navController: NavController) {
    OnboardingScreen(
        imageRes = R.drawable.onboarding3_image,
        title = "Track Your Orders",
        description = "Get real-time updates.",
        isFirst = false,
        isLast = true,
        onNextClick = { navController.navigate("main") },
        onSkipClick = { navController.navigate("main") }
    )
}