package com.project.e_commerce.android.presentation.ui.composable.composableScreen.specific.product

import androidx.annotation.DrawableRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.example.achiver.presentation.ui.composable.spacerComposable.SpacerVerticalSmall
import com.project.e_commerce.android.R
import com.project.e_commerce.android.presentation.ui.composable.composableScreen.public.StarRating
import com.project.e_commerce.android.presentation.ui.composable.spacerComposable.SpacerHorizontalSmall
import com.project.e_commerce.android.presentation.ui.composable.spacerComposable.SpacerHorizontalTiny
import com.project.e_commerce.android.presentation.ui.utail.BlackColor37
import com.project.e_commerce.android.presentation.ui.utail.BlackColor80
import com.project.e_commerce.android.presentation.ui.utail.ErrorPrimaryColor
import com.project.e_commerce.android.presentation.ui.utail.SecondaryColor
import com.project.e_commerce.android.presentation.ui.utail.UnitsApplication
import com.project.e_commerce.android.presentation.ui.utail.UnitsApplication.smallFontSize
import com.project.e_commerce.android.presentation.ui.utail.UnitsApplication.tinyFontSize
import com.project.e_commerce.android.presentation.ui.utail.UnitsApplication.tinyUnit
import com.project.e_commerce.android.presentation.ui.utail.UnitsApplication.titleFontSize

@Composable
fun ProductCard(
    @DrawableRes image: Int,
    title: String,
    category: String,
    price: Int,
    offerPrice: Int? = null,
    rate: Int,
    colors: List<Color>,
    isHasOffer: Boolean = false,
    isRemovable: Boolean = false,
    onClickRemove: () -> Unit = {},
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(128.dp)
            .clickable { onClick() }
        ,
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        ),
        elevation = CardDefaults.elevatedCardElevation(2.dp),
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(tinyUnit)
                .clickable { onClick() },
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column() {
                Image(
                    painter = painterResource(id = image),
                    contentDescription = null,
                    modifier = Modifier.width(72.dp)
                )
            }

            Column(modifier = Modifier.fillMaxHeight(), verticalArrangement = Arrangement.Center) {
                if (isRemovable) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = tinyUnit),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = title,
                            fontSize = titleFontSize,
                            fontWeight = FontWeight.SemiBold,
                            color = BlackColor80
                        )
                        Icon(
                            painter = painterResource(id = R.drawable.ic_remove_product),
                            contentDescription = null,
                            tint = ErrorPrimaryColor,
                            modifier = Modifier.clickable { onClickRemove() }
                        )
                    }
                } else
                    Text(
                        text = title,
                        fontSize = titleFontSize,
                        fontWeight = FontWeight.SemiBold,
                        color = BlackColor80
                    )
                SpacerVerticalSmall()
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        modifier = Modifier
                            .width(64.dp)
                            .height(32.dp)
                            .background(SecondaryColor, RoundedCornerShape(100))
                            .clickable { onClick() },
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = category,
                            fontSize = smallFontSize,
                            fontWeight = FontWeight.Medium,
                            color = Color.White
                        )
                    }
                    SpacerHorizontalTiny()

                    Text(
                        text = "$price$",
                        fontSize = smallFontSize,
                        fontWeight = FontWeight.Medium,
                        color = BlackColor80
                    )
                    if(isHasOffer) {
                        Text(
                            text = "$offerPrice$",
                            fontSize = tinyFontSize,
                            fontWeight = FontWeight.Normal,
                            color = BlackColor37,
                            textDecoration = TextDecoration.LineThrough
                        )
                    }
                    SpacerHorizontalTiny()
                    StarRating(rating = rate, onRatingChange = {})
                }
                SpacerVerticalSmall()

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "الالوان المتوفرة",
                        fontSize = smallFontSize,
                        fontWeight = FontWeight.Medium,
                        color = BlackColor80
                    )
                    SpacerHorizontalTiny()
                    colors.map { color ->
                        Box(
                            modifier = Modifier
                                .size(UnitsApplication.largeUnit)
                                .background(color, shape = RoundedCornerShape(12))
                        )
                        SpacerHorizontalSmall()
                    }
                }
            }
        }
    }

}

