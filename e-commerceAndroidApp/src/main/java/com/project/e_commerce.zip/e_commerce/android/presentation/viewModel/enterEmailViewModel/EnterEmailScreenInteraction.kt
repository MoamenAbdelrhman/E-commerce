package com.project.e_commerce.android.presentation.viewModel.enterEmailViewModel

import androidx.navigation.NavController

interface EnterEmailScreenInteraction {

    fun onUserWriteEmail(email: String)

    fun onUserClickSendVerifyCode(navController: NavController)

    fun onClickBackToLogin(navController: NavController)


}