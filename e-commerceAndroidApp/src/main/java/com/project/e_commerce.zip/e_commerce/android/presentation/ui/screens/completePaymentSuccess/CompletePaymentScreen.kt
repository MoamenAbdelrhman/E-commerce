package com.project.e_commerce.android.presentation.ui.screens.completePaymentSuccess

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.achiver.presentation.ui.composable.spacerComposable.SpacerVerticalTiny
import com.project.e_commerce.android.R
import com.project.e_commerce.android.presentation.ui.composable.composableScreen.public.LottieAnimationComponent
import com.project.e_commerce.android.presentation.ui.composable.composableScreen.public.PrimaryButton
import com.project.e_commerce.android.presentation.ui.composable.spacerComposable.SpacerHorizontalSmall
import com.project.e_commerce.android.presentation.ui.navigation.Screens
import com.project.e_commerce.android.presentation.ui.screens.AddNewProductScreen
import com.project.e_commerce.android.presentation.ui.utail.BlackColor80
import com.project.e_commerce.android.presentation.ui.utail.UnitsApplication
import com.project.e_commerce.android.presentation.ui.utail.UnitsApplication.mediumFontSize
import com.project.e_commerce.android.presentation.ui.utail.UnitsApplication.mediumUnit
import com.project.e_commerce.android.presentation.ui.utail.UnitsApplication.smallFontSize
import com.project.e_commerce.android.presentation.ui.utail.noRippleClickable

@Composable
fun CompletePaymentScreen(navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(mediumUnit),
        verticalArrangement = Arrangement.SpaceBetween,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            horizontalArrangement = Arrangement.spacedBy(UnitsApplication.smallUnit),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                painter = painterResource(id = R.drawable.ic_left_arrow),
                contentDescription = null,
                tint = BlackColor80,
                modifier = Modifier.noRippleClickable { navController.popBackStack() }
            )
            SpacerHorizontalSmall()
            Text(
                text = "حالة الدفع",
                fontSize = UnitsApplication.mediumFontSize,
                color = BlackColor80,
                fontWeight = FontWeight.SemiBold
            )
        }

        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            LottieAnimationComponent(animationLottie = R.raw.correct_animation, isLoop = false)
            Text(
                text = "تم تحويل المبلغ المالي ",
                fontSize = mediumFontSize,
                color = BlackColor80,
                fontWeight = FontWeight.SemiBold,

                )
            SpacerVerticalTiny()
            Text(
                text = "سيصلك طلبك خلال 3   أيام القادمة",
                fontSize = smallFontSize,
                color = BlackColor80,
                fontWeight = FontWeight.Medium,
            )
        }
        PrimaryButton(
            textButton = "اضافة تقييم",
            onClick = {
            }, isLoading = false
        )
    }
}


@Preview(showBackground = true, showSystemUi = true)
@Composable
fun PreviewCompletePaymentScreen() {
    val navController = rememberNavController()
    CompletePaymentScreen(navController = navController)
}
