package com.project.e_commerce.android.presentation.ui.composable.composableScreen.public

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material.Button
import androidx.compose.material.ButtonDefaults
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.project.e_commerce.android.R
import com.project.e_commerce.android.presentation.ui.utail.PrimaryColor
import com.project.e_commerce.android.presentation.ui.utail.UnitsApplication

@Composable
fun PrimaryButton(
    textButton: String,
    onClick: () -> Unit,
    isLoading: Boolean,
    enabled: Boolean = true
){
    Button(
        enabled = enabled,
        onClick = {
            onClick()
        },
        modifier = Modifier
            .fillMaxWidth()
            .height(52.dp),
        colors = ButtonDefaults.buttonColors(
            backgroundColor = PrimaryColor
        ),
    ) {
        if (isLoading)
            LottieAnimationComponent(
                animationLottie = R.raw.loading_animation, isLoop = true,
                modifier = Modifier.fillMaxSize()
            )
        else
            Text(
                text = textButton,
                fontSize = UnitsApplication.xSmallFontSize,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center
            )
    }
}