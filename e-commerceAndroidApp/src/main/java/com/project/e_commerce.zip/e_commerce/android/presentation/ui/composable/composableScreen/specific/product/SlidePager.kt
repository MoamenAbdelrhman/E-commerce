package com.project.e_commerce.android.presentation.ui.composable.composableScreen.specific.product

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.project.e_commerce.android.presentation.ui.utail.PrimaryColor37Degree
import com.project.e_commerce.android.presentation.ui.utail.PrimaryColor80Degree
import com.project.e_commerce.android.presentation.ui.utail.UnitsApplication
import com.tbuonomo.viewpagerdotsindicator.compose.DotsIndicator
import com.tbuonomo.viewpagerdotsindicator.compose.model.DotGraphic
import com.tbuonomo.viewpagerdotsindicator.compose.type.SpringIndicatorType
import kotlinx.coroutines.delay

@Composable
fun SlidePager(images: List<Int>) {
    val pagerState = rememberPagerState(
        pageCount = { images.size }
    )
    LaunchedEffect(Unit) {
        while (true) {
            delay(5000)
            val nextPage = (pagerState.currentPage + 1) % pagerState.pageCount
            pagerState.scrollToPage(nextPage)
        }
    }
    Column(
        Modifier
            .fillMaxWidth()
            .fillMaxHeight()
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(.90f),
            contentAlignment = Alignment.Center
        ) {
            HorizontalPager(
                state = pagerState,
                Modifier
                    .fillMaxWidth()

            ) { currentPage ->

                Card(
                    Modifier
                        .fillMaxWidth(),
                    elevation = CardDefaults.cardElevation(4.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = Color.White
                    )
                ) {
                    Image(
                        painter = painterResource(id = images[currentPage]),
                        contentDescription = "",
                        modifier = Modifier
                            .fillMaxWidth()
                            .fillMaxHeight(),
                        contentScale = ContentScale.Inside
                    )
                }
            }
            DotsIndicator(
                dotCount = images.size,
                type = SpringIndicatorType(
                    dotsGraphic = DotGraphic(
                        UnitsApplication.xSmallUnit,
                        borderWidth = 2.dp,
                        borderColor = PrimaryColor37Degree,
                        color = Color.Transparent
                    ),
                    selectorDotGraphic = DotGraphic(
                        UnitsApplication.smallUnit,
                        color = PrimaryColor80Degree
                    )
                ),
                pagerState = pagerState,
                dotSpacing = UnitsApplication.tinyUnit,
                modifier = Modifier
                    .padding(top = UnitsApplication.largeUnit)
                    .align(Alignment.BottomCenter)
            )
        }
    }
}
