package com.project.e_commerce.android.presentation.ui.screens.enterEmailScreen

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Icon
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.achiver.presentation.ui.composable.spacerComposable.SpacerVerticalMedium
import com.example.achiver.presentation.ui.composable.spacerComposable.SpacerVerticalSmall
import com.example.achiver.presentation.ui.composable.spacerComposable.SpacerVerticalTiny
import com.project.e_commerce.android.R
import com.project.e_commerce.android.presentation.ui.composable.composableScreen.public.InputField
import com.project.e_commerce.android.presentation.ui.composable.composableScreen.public.PrimaryButton
import com.project.e_commerce.android.presentation.ui.composable.spacerComposable.SpacerHorizontalSmall
import com.project.e_commerce.android.presentation.ui.utail.BlackColor
import com.project.e_commerce.android.presentation.ui.utail.BlackColor60
import com.project.e_commerce.android.presentation.ui.utail.BlackColor80
import com.project.e_commerce.android.presentation.ui.utail.ErrorPrimaryColor
import com.project.e_commerce.android.presentation.ui.utail.PrimaryColor
import com.project.e_commerce.android.presentation.ui.utail.PrimaryColor60Degree
import com.project.e_commerce.android.presentation.ui.utail.UnitsApplication
import com.project.e_commerce.android.presentation.ui.utail.UnitsApplication.mediumUnit
import com.project.e_commerce.android.presentation.ui.utail.UnitsApplication.tinyUnit
import com.project.e_commerce.android.presentation.ui.utail.UnitsApplication.xLargeUnit
import com.project.e_commerce.android.presentation.ui.utail.UnitsApplication.xxLargeUnit
import com.project.e_commerce.android.presentation.ui.utail.noRippleClickable
import com.project.e_commerce.android.presentation.viewModel.enterEmailViewModel.EnterEmailViewModel
import org.koin.androidx.compose.koinViewModel

@Composable
fun EnterEmailScreen(navController: NavController) {
    val viewModel: EnterEmailViewModel = koinViewModel()
    val state by viewModel.state.collectAsState()
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight(.85f)
            .padding(horizontal = mediumUnit)
            .background(Color.White),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Column(
            modifier = Modifier
                .size(xxLargeUnit)
                .border(
                    1.dp, PrimaryColor60Degree, shape = RoundedCornerShape(
                        tinyUnit
                    )
                ),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Icon(
                painter = painterResource(id = R.drawable.ic_password_key),
                contentDescription = null,
                modifier = Modifier.size(xLargeUnit),
                tint = PrimaryColor
            )
        }
        SpacerVerticalMedium()
        Text(
            text = stringResource(R.string.forget_my_password),
            fontSize = UnitsApplication.titleSectionFontSize,
            fontWeight = FontWeight.SemiBold,
            color = BlackColor80,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center
        )
        SpacerVerticalTiny()
        Text(
            text = stringResource(R.string.we_will_send_the_verify_code_to_your_email),
            fontSize = UnitsApplication.smallFontSize,
            fontWeight = FontWeight.Medium,
            color = BlackColor,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center
        )
        SpacerVerticalMedium()
        InputField(
            value = state.email.email,
            onValueChange = { viewModel.onUserWriteEmail(it) },
            placeholderText = stringResource(R.string.email),
            leadingIconId = R.drawable.ic_email,
            isError = state.email.isError,

            )

        SpacerVerticalSmall()
        if (state.email.isError) {
            Text(
                text = state.email.errorMessage,
                color = ErrorPrimaryColor,
                fontWeight = FontWeight.Light,
                fontSize = UnitsApplication.tinyFontSize,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Start
            )
            SpacerVerticalSmall()
        }
        PrimaryButton(
            textButton = stringResource(R.string.send_verify_code),
            onClick = {
                viewModel.onUserClickSendVerifyCode(navController = navController)
            },
            isLoading = state.isLoading
        )

        SpacerVerticalSmall()
        if (state.isError) {
            Text(
                text = state.errorMessage,
                color = ErrorPrimaryColor,
                fontWeight = FontWeight.Normal,
                fontSize = UnitsApplication.tinyFontSize,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Start
            )
        }
        SpacerVerticalSmall()
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {

            Icon(
                painter = painterResource(id = R.drawable.ic_left_arrow),
                contentDescription = null,
                tint = BlackColor60,
                modifier = Modifier.noRippleClickable {
                    viewModel.onClickBackToLogin(navController)
                }
            )
            SpacerHorizontalSmall()
            Text(
                text = stringResource(R.string.back_to_login_screen),
                color = BlackColor60,
                fontWeight = FontWeight.SemiBold,
                fontSize = UnitsApplication.smallFontSize,
                modifier = Modifier
                    .noRippleClickable {
                        viewModel.onClickBackToLogin(navController)
                    },
                textAlign = TextAlign.Center
            )
        }
    }
}
