package com.project.e_commerce.android.presentation.viewModel.verifyScreenViewModel

import androidx.lifecycle.viewModelScope
import androidx.navigation.NavController
import com.project.e_commerce.android.presentation.ui.navigation.Screens
import com.project.e_commerce.android.presentation.ui.screens.verifyCodeScreen.VerifyCodeUiState
import com.project.e_commerce.android.presentation.viewModel.baseViewModel.BaseViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class VerifyCodeViewModel : VerifyCodeScreenInteraction,BaseViewModel() {

    private val _state = MutableStateFlow(VerifyCodeUiState())

    val state : StateFlow<VerifyCodeUiState> get() = _state



    override fun onWriteVerifyCode(code: String) {
        val copyState = _state.value.copy(
            fieldStatus = _state.value.fieldStatus.copy(
                value = code
            )
        )
        viewModelScope.launch {
            _state.emit(copyState)
        }
    }

    override fun onClickBackToLogin(navController: NavController) {
      navController.navigate(Screens.LoginScreen.route)
    }

    override fun onClickConfirm(navController: NavController) {
        navController.navigate(Screens.LoginScreen.ResetPasswordScreen.route)
    }

    override fun onClickReSendCode() {

    }

    override fun setLoadingState(loadingState: Boolean) {
        val copyState = _state.value.copy(
            isLoading = loadingState
        )
        viewModelScope.launch {
            _state.emit(copyState)
        }
    }

    override fun setErrorState(errorState: Boolean, errorMessage: String) {
        val copyState = _state.value.copy(
            isError = errorState,
            errorMessage = errorMessage
        )
        viewModelScope.launch {
            _state.emit(copyState)
        }    }
}
