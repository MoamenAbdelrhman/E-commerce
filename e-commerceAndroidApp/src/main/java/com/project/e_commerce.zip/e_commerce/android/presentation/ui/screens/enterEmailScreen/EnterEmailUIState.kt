package com.project.e_commerce.android.presentation.ui.screens.enterEmailScreen

import com.project.e_commerce.android.presentation.ui.screens.loginScreen.EmailField

data class EnterEmailUIState(
    val email: EmailField = EmailField(),
    val errorMessage: String = "",
    val isError: Boolean = false,
    val isLoading: Boolean = false
)

