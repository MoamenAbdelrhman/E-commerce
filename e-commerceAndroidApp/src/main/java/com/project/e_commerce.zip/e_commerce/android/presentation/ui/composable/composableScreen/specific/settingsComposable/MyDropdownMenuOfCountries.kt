package com.project.e_commerce.android.presentation.ui.composable.composableScreen.specific.settingsComposable

import android.annotation.SuppressLint
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.DropdownMenu
//noinspection UsingMaterialAndMaterial3Libraries
import androidx.compose.material.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.bumptech.glide.integration.compose.ExperimentalGlideComposeApi
import com.bumptech.glide.integration.compose.GlideImage
import com.project.e_commerce.android.R
import com.project.e_commerce.android.data.remote.response.CountryResponse
import com.project.e_commerce.android.presentation.ui.composable.spacerComposable.SpacerHorizontalTiny
import com.project.e_commerce.android.presentation.ui.screens.settingScreen.SettingScreenUIState
import com.project.e_commerce.android.presentation.ui.utail.BlackColor80
import com.project.e_commerce.android.presentation.ui.utail.UnitsApplication

@SuppressLint("SuspiciousIndentation")
@OptIn(ExperimentalGlideComposeApi::class)
@Composable
fun MyDropdownMenuOfCountries(
    items: SettingScreenUIState,
    onSelected: (CountryResponse) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    var selectedIndex by remember { mutableStateOf(0) }

    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(1.dp)
                .clickable { expanded = true }
                .padding(
                    UnitsApplication.mediumUnit
                ),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Row (verticalAlignment = Alignment.CenterVertically){
                Text(
                    text = if (items.isLoading) "تحميل ..."
                    else if(items.isError)
                        items.errorMessage
                    else{
                        if (items.countries.isNotEmpty()) items.countries[selectedIndex].name.common
                        else ""}
                )
                SpacerHorizontalTiny()
                GlideImage(
                    model = if (items.countries.isNotEmpty()) items.countries[selectedIndex].flags.png else null,
                    contentDescription = null,
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape),
                    contentScale = ContentScale.Crop
                )

            }

            Icon(
                painter = painterResource(id = R.drawable.ic_left_arrow),
                contentDescription = null,
                tint = BlackColor80,
                modifier = Modifier
                    .size(UnitsApplication.mediumUnit)
                    .rotate(90f)
            )

        }

        DropdownMenu(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = UnitsApplication.mediumUnit),
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            items.countries.forEachIndexed { index, item ->
                if (item.name.common != "Israel")
                    DropdownMenuItem(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = UnitsApplication.mediumUnit),
                        onClick = {
                            selectedIndex = index
                            onSelected(item)
                            expanded = false
                        }
                    ) {

                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = UnitsApplication.tinyUnit),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = item.name.common)
                            GlideImage(
                                model = item.flags.png,
                                contentDescription = null,
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape),
                                contentScale = ContentScale.Crop
                            )
                        }

                    }
            }
        }
    }
}
