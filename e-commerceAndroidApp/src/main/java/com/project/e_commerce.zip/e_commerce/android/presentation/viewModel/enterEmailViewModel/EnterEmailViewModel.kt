package com.project.e_commerce.android.presentation.viewModel.enterEmailViewModel

import androidx.lifecycle.viewModelScope
import androidx.navigation.NavController
import com.project.e_commerce.android.domain.usecase.CheckEmailValidation
import com.project.e_commerce.android.domain.usecase.SendEmailToSendTheVerifiedCode
import com.project.e_commerce.android.presentation.ui.navigation.Screens
import com.project.e_commerce.android.presentation.ui.screens.enterEmailScreen.EnterEmailUIState
import com.project.e_commerce.android.presentation.viewModel.baseViewModel.BaseViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class EnterEmailViewModel(
    private val checkEmailValidation: CheckEmailValidation,
    private val sendEmailToSendTheVerifiedCode: SendEmailToSendTheVerifiedCode
) : BaseViewModel(), EnterEmailScreenInteraction {

    private val _state = MutableStateFlow(EnterEmailUIState())

    val state: StateFlow<EnterEmailUIState> get() = _state


    override fun onUserWriteEmail(email: String) {
        val validation = checkEmailValidation.invoke(email)
        val copyState = _state.value.copy(
            email = _state.value.email.copy(
                email = email,
                isError = validation.first,
                errorMessage = validation.second
            )
        )
        viewModelScope.launch {
            _state.emit(copyState)
        }
    }

    override fun onUserClickSendVerifyCode(navController: NavController) {
        setLoadingState(true)
        if(!checkEmailValidation.invoke(_state.value.email.email).first) {
            setLoadingState(false)
            navController.navigate(Screens.LoginScreen.VerifyCodeScreen.route)

        }
        else {
            viewModelScope.launch {
                delay(3000)
                setLoadingState(false)
                setErrorState(true, "رجاءا ادخل ايميل صحيح")
            }
        }

    }

    override fun onClickBackToLogin(navController: NavController) {
        navController.navigate(Screens.LoginScreen.route)
    }


    override fun setLoadingState(loadingState: Boolean) {
        val copyState = _state.value.copy(
            isLoading = loadingState
        )
        viewModelScope.launch {
            _state.emit(copyState)
        }
    }

    override fun setErrorState(errorState: Boolean, errorMessage: String) {
        val copyState = _state.value.copy(
            isError = errorState,
            errorMessage = errorMessage
        )
        viewModelScope.launch {
            _state.emit(copyState)
        }
    }
}