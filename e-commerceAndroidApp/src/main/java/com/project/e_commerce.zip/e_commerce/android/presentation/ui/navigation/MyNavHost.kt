package com.project.e_commerce.android.presentation.ui.navigation

import SearchScreen
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.project.e_commerce.android.presentation.ui.screens.AddNewProductScreen
import com.project.e_commerce.android.presentation.ui.screens.AddNewReelScreen
import com.project.e_commerce.android.presentation.ui.screens.CartScreen
import com.project.e_commerce.android.presentation.ui.screens.DetailsScreen
import com.project.e_commerce.android.presentation.ui.screens.EditProductScreen
import com.project.e_commerce.android.presentation.ui.screens.EditProfileScreen
import com.project.e_commerce.android.presentation.ui.screens.EditReelScreen
import com.project.e_commerce.android.presentation.ui.screens.FavouriteScreen
import com.project.e_commerce.android.presentation.ui.screens.NotificationScreen
import com.project.e_commerce.android.presentation.ui.screens.OrdersHistoryScreen
import com.project.e_commerce.android.presentation.ui.screens.ProductScreen
import com.project.e_commerce.android.presentation.ui.screens.RecentlyViewedScreen
import com.project.e_commerce.android.presentation.ui.screens.SettingsScreen
import com.project.e_commerce.android.presentation.ui.screens.createAccountScreen.CreateAnAccountScreen
import com.project.e_commerce.android.presentation.ui.screens.enterEmailScreen.EnterEmailScreen
import com.project.e_commerce.android.presentation.ui.screens.loginScreen.LoginScreen
import com.project.e_commerce.android.presentation.ui.screens.profileScreen.ProfileScreen
import com.project.e_commerce.android.presentation.ui.screens.reelsScreen.ReelsView
import com.project.e_commerce.android.presentation.ui.screens.requestHelpScreen.RequestHelpScreen
import com.project.e_commerce.android.presentation.ui.screens.changePasswordScreen.ChangePasswordScreen
import com.project.e_commerce.android.presentation.ui.screens.splashScreen.SplashScreen
import com.project.e_commerce.android.presentation.ui.screens.verifyCodeScreen.VerifyCodeScreen

@RequiresApi(Build.VERSION_CODES.O)
@Composable
fun MyNavHost( navController: NavHostController = rememberNavController()) {

    NavHost(
        navController = navController,
        startDestination = Screens.SplashScreen.route
    ) {
        composable(Screens.SplashScreen.route){ SplashScreen(navController = navController)}
        composable(Screens.LoginScreen.route) { LoginScreen(navController) }
        composable(Screens.LoginScreen.EnterEmailScreen.route) { EnterEmailScreen(navController) }
        composable(Screens.LoginScreen.CreateAccountScreen.route) {
            CreateAnAccountScreen(
                navController
            )
        }
        composable(Screens.LoginScreen.VerifyCodeScreen.route) { VerifyCodeScreen(navController) }
        composable(Screens.LoginScreen.ResetPasswordScreen.route) { ChangePasswordScreen(navController) }
        composable(Screens.ReelsScreen.route) { ReelsView(navController) }
        composable(Screens.ReelsScreen.SearchScreen.route) { SearchScreen(navController) }

        composable(Screens.ProductScreen.route) { ProductScreen(navController) }


        composable(Screens.ProductScreen.SearchScreen.route) {
            SearchScreen(navController = navController)
        }

        composable(
            route = Screens.ProductScreen.DetailsScreen.route + "/{productId}",
            arguments = listOf(navArgument("productId") { type = NavType.StringType })
        ) { backStackEntry ->
            val productId = backStackEntry.arguments?.getString("productId") ?: ""
            DetailsScreen(navController = navController, productId = productId)
        }

        composable(Screens.ProfileScreen.route) { ProfileScreen(navController) }

        composable(Screens.ProfileScreen.EditPersonalProfile.route) {
            EditProfileScreen(
                navController = navController
            )
        }
        composable(Screens.ProfileScreen.FavouritesScreen.route) {
            FavouriteScreen(
                navController = navController
            )
        }

        composable(Screens.ProfileScreen.RecentlyScreen.route) {
            RecentlyViewedScreen(navController = navController)
        }

        composable(Screens.ProfileScreen.OrdersHistoryScreen.route) {
            OrdersHistoryScreen(navController = navController)
        }

        composable(Screens.ProfileScreen.SettingsScreen.route) {
            SettingsScreen(navController = navController)
        }

        composable(Screens.ProfileScreen.AddNewProductScreen.route) {
            AddNewProductScreen(navController = navController)
        }

        composable(Screens.ProfileScreen.AddNewReelScreen.route) {
            AddNewReelScreen(navController = navController)
        }

        composable(Screens.ProfileScreen.RequestHelpScreen.route) { RequestHelpScreen(navController = navController) }

        composable(Screens.ProfileScreen.NotificationScreen.route) { NotificationScreen(
            navController = navController
        )}

        composable(Screens.ProfileScreen.EditProfileScreen.route) {
            EditProfileScreen(navController)
        }
        composable(
            route = Screens.ProfileScreen.EditReelScreen.route,
            arguments = listOf(navArgument("reelId") { type = NavType.StringType })
        ) { backStackEntry ->
            val reelId = backStackEntry.arguments?.getString("reelId") ?: "0"
            EditReelScreen(navController, reelId)
        }
        composable(
            route = Screens.ProfileScreen.EditProductScreen.route,
            arguments = listOf(navArgument("productId") { type = NavType.StringType })
        ) { backStackEntry ->
            val productId = backStackEntry.arguments?.getString("productId") ?: "0"
            EditProductScreen(navController, productId)
        }

        composable(Screens.CartScreen.route){ CartScreen(navController = navController) }
        composable(Screens.CartScreen.PaymentScreen.route){ com.project.e_commerce.android.presentation.ui.screens.PaymentScreen(navController = navController) }



    }
}