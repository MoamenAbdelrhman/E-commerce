package com.project.e_commerce.android.presentation.ui.screens.settingScreen

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.achiver.presentation.ui.composable.spacerComposable.SpacerVerticalMedium
import com.example.achiver.presentation.ui.composable.spacerComposable.SpacerVerticalSmall
import com.example.achiver.presentation.ui.composable.spacerComposable.SpacerVerticalTiny
import com.project.e_commerce.android.R
import com.project.e_commerce.android.presentation.ui.composable.composableScreen.public.MyDropdownMenu
import com.project.e_commerce.android.presentation.ui.composable.composableScreen.public.PrimaryButton
import com.project.e_commerce.android.presentation.ui.composable.composableScreen.specific.settingsComposable.MyDropdownMenuOfCountries
import com.project.e_commerce.android.presentation.ui.composable.spacerComposable.SpacerHorizontalSmall
import com.project.e_commerce.android.presentation.ui.utail.BlackColor80
import com.project.e_commerce.android.presentation.ui.utail.UnitsApplication
import com.project.e_commerce.android.presentation.ui.utail.UnitsApplication.mediumUnit
import com.project.e_commerce.android.presentation.ui.utail.noRippleClickable
import com.project.e_commerce.android.presentation.viewModel.settingsViewModel.SettingsViewModel
import org.koin.androidx.compose.koinViewModel

@Composable
fun SettingsScreen(navController: NavController) {
    val viewModel: SettingsViewModel = koinViewModel()
    val state by viewModel.state.collectAsState()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(mediumUnit),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            horizontalArrangement = Arrangement.spacedBy(UnitsApplication.smallUnit),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                painter = painterResource(id = R.drawable.ic_left_arrow),
                contentDescription = null,
                tint = BlackColor80,
                modifier = Modifier.noRippleClickable { navController.popBackStack() }
            )
            SpacerHorizontalSmall()
            Text(
                text = "الاعدادات",
                fontSize = UnitsApplication.mediumFontSize,
                color = BlackColor80,
                fontWeight = FontWeight.SemiBold
            )
        }
        SpacerVerticalMedium()
        Text(
            text = "اللغة",
            fontSize = UnitsApplication.smallFontSize,
            color = BlackColor80,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Start
        )
        SpacerVerticalTiny()
        MyDropdownMenu(listOf("عربي")) {
            viewModel.setSelectedLanguage(it)

        }
        SpacerVerticalSmall()
        Text(
            text = "الموقع",
            fontSize = UnitsApplication.smallFontSize,
            color = BlackColor80,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Start
        )
        SpacerVerticalTiny()
        MyDropdownMenuOfCountries(state) {
            viewModel.setSelectedCountry(it.name.common)
        }
        SpacerVerticalSmall()
        PrimaryButton(
            textButton = "حفظ",
            onClick = { viewModel.onClickSaveButton(navController) },
            isLoading = false
        )

    }
}


