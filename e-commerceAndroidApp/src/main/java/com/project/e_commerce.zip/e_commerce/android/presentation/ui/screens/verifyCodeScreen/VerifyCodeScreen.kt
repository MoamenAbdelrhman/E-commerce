package com.project.e_commerce.android.presentation.ui.screens.verifyCodeScreen

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Icon
import androidx.compose.material.Text
import androidx.compose.material.TextField
import androidx.compose.material.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.achiver.presentation.ui.composable.spacerComposable.SpacerVerticalMedium
import com.example.achiver.presentation.ui.composable.spacerComposable.SpacerVerticalSmall
import com.example.achiver.presentation.ui.composable.spacerComposable.SpacerVerticalTiny
import com.project.e_commerce.android.R
import com.project.e_commerce.android.presentation.ui.composable.composableScreen.public.PrimaryButton
import com.project.e_commerce.android.presentation.ui.composable.spacerComposable.SpacerHorizontalTiny
import com.project.e_commerce.android.presentation.ui.utail.BlackColor60
import com.project.e_commerce.android.presentation.ui.utail.BlackColor80
import com.project.e_commerce.android.presentation.ui.utail.ErrorPrimaryColor
import com.project.e_commerce.android.presentation.ui.utail.GrayColor80
import com.project.e_commerce.android.presentation.ui.utail.PrimaryColor
import com.project.e_commerce.android.presentation.ui.utail.PrimaryColor60Degree
import com.project.e_commerce.android.presentation.ui.utail.PrimaryGray
import com.project.e_commerce.android.presentation.ui.utail.SecondaryColor80Degree
import com.project.e_commerce.android.presentation.ui.utail.UnitsApplication
import com.project.e_commerce.android.presentation.ui.utail.UnitsApplication.smallFontSize
import com.project.e_commerce.android.presentation.ui.utail.noRippleClickable
import com.project.e_commerce.android.presentation.viewModel.verifyScreenViewModel.VerifyCodeViewModel
import org.koin.androidx.compose.koinViewModel

@Composable
fun VerifyCodeScreen(navController: NavController) {
    val viewModel: VerifyCodeViewModel = koinViewModel()
    val state by viewModel.state.collectAsState()
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight(.85f)
            .padding(horizontal = UnitsApplication.mediumUnit)
            .background(Color.White),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Column(
            modifier = Modifier
                .size(UnitsApplication.xxLargeUnit)
                .border(
                    1.dp, PrimaryColor60Degree, shape = RoundedCornerShape(
                        UnitsApplication.tinyUnit
                    )
                ),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Icon(
                painter = painterResource(id = R.drawable.ic_password_key),
                contentDescription = null,
                modifier = Modifier.size(UnitsApplication.xLargeUnit),
                tint = PrimaryColor
            )
        }
        SpacerVerticalMedium()
        Text(
            text = stringResource(R.string.enter_verify_code),
            fontSize = UnitsApplication.titleSectionFontSize,
            fontWeight = FontWeight.SemiBold,
            color = BlackColor80,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center
        )
        SpacerVerticalSmall()
        SpacerVerticalTiny()
        TextField(
            value = state.fieldStatus.value,
            onValueChange = { viewModel.onWriteVerifyCode(it)},
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    1.dp, color = GrayColor80
                ),
            placeholder = {
                Row {
                    Text(
                        text = stringResource(R.string.enter_verify_code),
                        color = PrimaryGray,
                        fontWeight = FontWeight.Normal,
                        fontSize = smallFontSize
                    )
                    Text(
                        text = "*",
                        color = ErrorPrimaryColor,
                        fontWeight = FontWeight.Normal,
                        fontSize = smallFontSize
                    )
                }
            },
            leadingIcon = {
                Image(
                    painterResource(id = R.drawable.ic_password_key),
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
            },
            colors = TextFieldDefaults.textFieldColors(
                cursorColor = PrimaryColor,
                textColor = PrimaryGray,
                backgroundColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                disabledIndicatorColor = Color.Transparent,
                focusedIndicatorColor = Color.Transparent,
                errorLabelColor = ErrorPrimaryColor,
                errorTrailingIconColor = ErrorPrimaryColor,
                errorLeadingIconColor = ErrorPrimaryColor,
                errorCursorColor = ErrorPrimaryColor,
                errorIndicatorColor = Color.Transparent
            )
        )
        SpacerVerticalSmall()
        SpacerVerticalTiny()
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {


            Text(
                text = stringResource(R.string.you_dont_get_verify_code),
                color = BlackColor80,
                fontWeight = FontWeight.SemiBold,
                fontSize = smallFontSize,
                modifier = Modifier
                    .noRippleClickable {
                        viewModel.onClickReSendCode()
                    },
                textAlign = TextAlign.Center
            )
            SpacerHorizontalTiny()
            Text(
                text = stringResource(R.string.re_send_verify_code),
                color = SecondaryColor80Degree,
                fontWeight = FontWeight.SemiBold,
                fontSize = smallFontSize,
                modifier = Modifier
                    .noRippleClickable {
                        viewModel.onClickReSendCode()
                    },
                textAlign = TextAlign.Center
            )
        }
        SpacerVerticalSmall()
        SpacerVerticalTiny()
        PrimaryButton(
            textButton = stringResource(R.string.comfirm),
            onClick = {
                viewModel.onClickConfirm(navController)
            },
            isLoading = state.isLoading
        )
        SpacerVerticalSmall()
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {

            Icon(
                painter = painterResource(id = R.drawable.ic_left_arrow),
                contentDescription = null,
                tint = BlackColor60,
                modifier = Modifier.noRippleClickable {
                    viewModel.onClickBackToLogin(navController)
                }
            )
            SpacerVerticalMedium()
            Text(
                text = stringResource(R.string.back_to_login_screen),
                color = BlackColor60,
                fontWeight = FontWeight.SemiBold,
                fontSize = smallFontSize,
                modifier = Modifier
                    .noRippleClickable {
                        viewModel.onClickBackToLogin(navController)
                    },
                textAlign = TextAlign.Center
            )
        }
    }
}

@Preview(showSystemUi = true, showBackground = true)
@Composable
private fun VerifyCodeScreenPreview() {
    VerifyCodeScreen(navController = rememberNavController())
}