package com.project.e_commerce.android.presentation.ui.screens.verifyCodeScreen

import com.project.e_commerce.android.data.model.FieldState

data class VerifyCodeUiState(
    val fieldStatus: FieldState = FieldState(),
    val isError: Boolean = false,
    val isLoading: Boolean = false,
    val errorMessage: String = ""
)

