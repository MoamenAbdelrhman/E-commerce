package com.project.e_commerce.android.presentation.ui.composable.composableScreen.specific.notificationComposable

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.achiver.presentation.ui.composable.spacerComposable.SpacerVerticalTiny
import com.project.e_commerce.android.R
import com.project.e_commerce.android.presentation.ui.utail.BlackColor
import com.project.e_commerce.android.presentation.ui.utail.PrimaryColor
import com.project.e_commerce.android.presentation.ui.utail.PrimaryGray
import com.project.e_commerce.android.presentation.ui.utail.UnitsApplication.smallFontSize
import com.project.e_commerce.android.presentation.ui.utail.UnitsApplication.smallUnit
import com.project.e_commerce.android.presentation.ui.utail.UnitsApplication.tinyUnit
import com.project.e_commerce.android.presentation.ui.utail.UnitsApplication.xLargeUnit
import com.project.e_commerce.android.presentation.ui.utail.UnitsApplication.xSmallFontSize

@Composable
fun NotificationCard(
    image: Int = R.drawable.charif_image,
    value: String,
    time: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(84.dp)
            .clickable{
                onClick()
            }
        ,
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        ),
        elevation = CardDefaults.elevatedCardElevation(1.dp),
        shape = RoundedCornerShape(smallUnit)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(smallUnit),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(
                smallUnit
            )
        ) {
            Image(
                painter = painterResource(id = image),
                contentDescription = null,
                modifier = Modifier
                    .size(xLargeUnit)
                    .clip(CircleShape)
            )
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(
                        tinyUnit
                    )
                ) {
                    Text(
                        text = value,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryColor,
                        fontSize = xSmallFontSize,
                    )
                    Text(
                        text = "علق على منشورك ",
                        fontWeight = FontWeight.SemiBold,
                        color = BlackColor,
                        fontSize = xSmallFontSize,
                    )

                }
                SpacerVerticalTiny()
                Text(
                    text = "قبل $time",
                    fontWeight = FontWeight.Medium,
                    color = PrimaryGray,
                    fontSize = smallFontSize,
                )
            }
        }
    }
}