package com.project.e_commerce.android.presentation.ui.screens.settingScreen

import com.project.e_commerce.android.data.remote.response.CountryResponse

data class SettingScreenUIState(
    val isLoading: Boolean = false,
    val isError: Boolean = false,
    val errorMessage: String = "",
    val countriesSelected: String = "",
    val languageSelected: String = "",
    val countries : List<CountryResponse> = emptyList()
)
