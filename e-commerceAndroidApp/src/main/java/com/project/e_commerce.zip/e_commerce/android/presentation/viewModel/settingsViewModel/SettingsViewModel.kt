package com.project.e_commerce.android.presentation.viewModel.settingsViewModel

import androidx.lifecycle.viewModelScope
import androidx.navigation.NavController
import com.project.e_commerce.android.data.repository.CountriesRepository
import com.project.e_commerce.android.presentation.ui.screens.settingScreen.SettingScreenUIState
import com.project.e_commerce.android.presentation.viewModel.baseViewModel.BaseViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val repository: CountriesRepository
): BaseViewModel() {

    private val _state = MutableStateFlow(SettingScreenUIState())
    val state = _state.asStateFlow()

    init{
        getAllCountries()
    }

    private fun getAllCountries(){
        setLoadingState(true)
        viewModelScope.launch {
            try {
                val copyState = _state.value.copy(
                    countries = repository.getAllCountries(),
                    isError = false,
                    isLoading = false,
                    errorMessage = ""
                )
                _state.emit(copyState)
            }catch (e: Exception) {
                val copyState = _state.value.copy(
                    isError = true,
                    isLoading = false,
                    errorMessage = ""
                )
                _state.emit(copyState)
            }
        }

    }

    fun setSelectedLanguage(language: String){
        val copyState = _state.value.copy(
            languageSelected = language
        )
        viewModelScope.launch {
            _state.emit(copyState)
        }
    }

    fun setSelectedCountry(country: String){
        val copyState = _state.value.copy(
            countriesSelected = country
        )
        viewModelScope.launch {
            _state.emit(copyState)
        }
    }

    fun onClickSaveButton(navController: NavController){
        navController.popBackStack()
    }

    override fun setLoadingState(loadingState: Boolean) {
        val copyState = _state.value.copy(
            isLoading = loadingState
        )
        viewModelScope.launch {
            _state.emit(copyState)
        }
    }

    override fun setErrorState(errorState: Boolean, errorMessage: String) {
        val copyState = _state.value.copy(
            isError = errorState,

            )
        viewModelScope.launch {
            _state.emit(copyState)
        }
    }
}