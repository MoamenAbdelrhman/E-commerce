package com.project.e_commerce.android.presentation.viewModel.verifyScreenViewModel

import androidx.navigation.NavController

interface VerifyCodeScreenInteraction {

    fun onWriteVerifyCode(code: String)

    fun onClickBackToLogin(navController: NavController)

    fun onClickConfirm(navController: NavController)

    fun onClickReSendCode()
}