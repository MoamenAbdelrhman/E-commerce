package com.project.e_commerce.android.data.model

data class FieldState(
    val value: String = "",
    val errorMessage: String = "",
    val isError: Boolean = false,

    )