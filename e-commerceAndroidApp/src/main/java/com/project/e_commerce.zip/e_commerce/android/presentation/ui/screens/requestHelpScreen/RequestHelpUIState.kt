package com.project.e_commerce.android.presentation.ui.screens.requestHelpScreen

data class RequestHelpUIState(
    val subjectMessage : String = "",
    val bodyMessage : String = "",
    val errorMessage : String = "",
    val isError : Boolean= false,
    val isLoading : Boolean= false
)
