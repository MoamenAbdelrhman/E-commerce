package com.project.e_commerce.android.presentation.ui.composable.composableScreen.public

import androidx.annotation.RawRes
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.airbnb.lottie.compose.LottieAnimation
import com.airbnb.lottie.compose.LottieCompositionSpec
import com.airbnb.lottie.compose.LottieConstants
import com.airbnb.lottie.compose.rememberLottieComposition
import com.project.e_commerce.android.R
import com.project.e_commerce.android.presentation.ui.utail.UnitsApplication


@Composable
fun LottieAnimationComponent(
    @RawRes animationLottie: Int,
    modifier : Modifier =  Modifier.width(224.dp).height(224.dp),
    isLoop: Boolean = true
){

    val composition by rememberLottieComposition(
        spec = LottieCompositionSpec.RawRes(animationLottie)
    )
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        LottieAnimation(
            composition = composition,
            modifier = modifier,
            iterations = if(isLoop) LottieConstants.IterateForever else 1 ,
            isPlaying = true
        )
    }
}

@Preview(showSystemUi = true, showBackground = true)
@Composable
private fun LottieAnimationComponentPreview(){
    LottieAnimationComponent(R.raw.loading_animation)
}