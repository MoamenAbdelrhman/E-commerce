package com.project.e_commerce.android.presentation.ui.composable.composableScreen.specific.product

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.achiver.presentation.ui.composable.spacerComposable.SpacerVerticalSmall
import com.example.achiver.presentation.ui.composable.spacerComposable.SpacerVerticalTiny
import com.project.e_commerce.android.R
import com.project.e_commerce.android.presentation.ui.utail.BlackColor37
import com.project.e_commerce.android.presentation.ui.utail.BlackColor80
import com.project.e_commerce.android.presentation.ui.utail.GrayColor60
import com.project.e_commerce.android.presentation.ui.utail.PrimaryColor
import com.project.e_commerce.android.presentation.ui.utail.UnitsApplication
import com.project.e_commerce.android.presentation.ui.utail.UnitsApplication.largeUnit
import com.project.e_commerce.android.presentation.ui.utail.UnitsApplication.mediumUnit
import com.project.e_commerce.android.presentation.ui.utail.UnitsApplication.smallUnit
import com.project.e_commerce.android.presentation.ui.utail.UnitsApplication.tinyUnit
import com.project.e_commerce.android.presentation.ui.utail.UnitsApplication.xLargeUnit
import com.project.e_commerce.android.presentation.ui.utail.noRippleClickable

@Composable
fun ProductRequestCard(
    colors: List<Color>,
    sizes: List<String>,
    amount: Int,
    selectedColor: Color? ,
    selectedSize: String?,
    onClickIncrease: () -> Unit,
    onClickDecrease: () -> Unit,
    onClickRemoveRequest: () -> Unit,
    onSelectedColor: (Color) -> Unit,
    onSelectedSize: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = mediumUnit)
            .background(Color.White)
            .border(1.dp, color = BlackColor37, shape = RoundedCornerShape(12))
    ) {
        Box(modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = largeUnit), contentAlignment = Alignment.TopEnd) {
            Icon(
                painter = painterResource(id = R.drawable.ic_remove_product),
                contentDescription = null,
                modifier = Modifier
                    .clickable { onClickRemoveRequest() }
                    .offset(y = 12.dp, x = 12.dp)
            )
        }
        SpacerVerticalSmall()
        SpacerVerticalTiny()
        Column(
            Modifier
                .fillMaxWidth()
                .padding(smallUnit)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(tinyUnit),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = stringResource(R.string.the_color),
                    fontSize = UnitsApplication.smallFontSize,
                    fontWeight = FontWeight.SemiBold,
                    color = BlackColor80
                )
                LazyRow(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(tinyUnit)
                ) {
                    colors.map { color ->
                        item {
                            Box(
                                modifier = Modifier
                                    .size(largeUnit)
                                    .border(
                                        width = if (color == selectedColor) 2.dp else 0.dp,
                                        color = if (color == selectedColor) Color.Black else Color.Transparent
                                    )
                                    .shadow(smallUnit)
                                    .background(color, shape = RoundedCornerShape(12))
                                    .noRippleClickable { onSelectedColor(color) }
                            )
                        }
                    }
                }

            }
            SpacerVerticalSmall()
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(tinyUnit),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = stringResource(R.string.the_size),
                    fontSize = UnitsApplication.smallFontSize,
                    fontWeight = FontWeight.SemiBold,
                    color = BlackColor80
                )
                LazyRow(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(tinyUnit)
                ) {
                    sizes.map { size ->
                        item {
                            Box(
                                modifier = Modifier
                                    .size(xLargeUnit)
                                    .background(if(selectedSize == size) BlackColor80 else Color.White,
                                        shape = RoundedCornerShape(12))
                                    .border(1.dp, color = BlackColor37, RoundedCornerShape(4))
                                    .noRippleClickable { onSelectedSize(size) }
                                ,
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = size,
                                    fontSize = UnitsApplication.tinyFontSize,
                                    fontWeight = FontWeight.Normal,
                                    color = if(selectedSize == size) Color.White else BlackColor80
                                )
                            }
                        }
                    }
                }

            }
            SpacerVerticalSmall()
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(tinyUnit),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = stringResource(R.string.amount),
                    fontSize = UnitsApplication.smallFontSize,
                    fontWeight = FontWeight.SemiBold,
                    color = BlackColor80
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(
                        tinyUnit
                    )
                ) {
                    Box(
                        modifier = Modifier
                            .size(largeUnit)
                            .background(PrimaryColor, RoundedCornerShape(100))
                            .noRippleClickable { onClickIncrease() }
                        ,
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            painter = painterResource(id = R.drawable.ic_increase),
                            contentDescription = null,
                            tint = Color.White
                        )

                    }
                    Text(text = amount.toString())
                    Box(
                        modifier = Modifier
                            .size(largeUnit)
                            .background(GrayColor60, RoundedCornerShape(100))
                            .noRippleClickable { onClickDecrease() }

                        ,
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            painter = painterResource(id = R.drawable.ic_remove_product),
                            contentDescription = null,
                            tint = Color.White
                        )
                    }
                }
            }
        }
    }

}
