package com.project.e_commerce.android.presentation.ui.composable.composableScreen.specific.profileComposable

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.project.e_commerce.android.R
import com.project.e_commerce.android.presentation.ui.composable.spacerComposable.SpacerHorizontalSmall
import com.project.e_commerce.android.presentation.ui.utail.BlackColor37
import com.project.e_commerce.android.presentation.ui.utail.BlackColor80
import com.project.e_commerce.android.presentation.ui.utail.ErrorSecondaryColor
import com.project.e_commerce.android.presentation.ui.utail.UnitsApplication

@Composable
fun ProfileOption(
    name: String,
    icon: Int,
    onClick: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(56.dp)
            .padding(horizontal = UnitsApplication.mediumUnit)
            .clickable {
                onClick()
            },
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,

        ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                painter = painterResource(icon),
                contentDescription = null,
                modifier = Modifier.size(UnitsApplication.largeUnit),
                tint = if (icon == R.drawable.ic_logout) ErrorSecondaryColor else BlackColor80
            )
            SpacerHorizontalSmall()
            Text(
                text = name,
                fontSize = UnitsApplication.smallFontSize,
                fontWeight = FontWeight.SemiBold,
                color = if (icon == R.drawable.ic_logout) ErrorSecondaryColor else BlackColor80
            )
        }
        if (icon != R.drawable.ic_logout)
            Icon(
                painter = painterResource(id = R.drawable.ic_left_arrow),
                contentDescription = null,
                modifier = Modifier.rotate(180f),
                tint = BlackColor80
            )
    }
    HorizontalDivider(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = UnitsApplication.mediumUnit),
        thickness = 1.dp,
        color = if (icon == R.drawable.ic_logout) ErrorSecondaryColor else BlackColor37
    )
}