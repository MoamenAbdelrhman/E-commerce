package com.project.e_commerce.android.presentation.ui.screens.requestHelpScreen

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.achiver.presentation.ui.composable.spacerComposable.SpacerVerticalMedium
import com.project.e_commerce.android.R
import com.project.e_commerce.android.presentation.ui.composable.composableScreen.public.InputField
import com.project.e_commerce.android.presentation.ui.composable.composableScreen.public.PrimaryButton
import com.project.e_commerce.android.presentation.ui.composable.spacerComposable.SpacerHorizontalSmall
import com.project.e_commerce.android.presentation.ui.utail.BlackColor80
import com.project.e_commerce.android.presentation.ui.utail.UnitsApplication
import com.project.e_commerce.android.presentation.ui.utail.UnitsApplication.mediumUnit
import com.project.e_commerce.android.presentation.ui.utail.noRippleClickable
import com.project.e_commerce.android.presentation.viewModel.RequestHelpViewModel
import org.koin.androidx.compose.koinViewModel

@Composable
fun RequestHelpScreen(navController: NavController) {
    val viewModel: RequestHelpViewModel = koinViewModel()
    val state by viewModel.state.collectAsState()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(mediumUnit),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            horizontalArrangement = Arrangement.spacedBy(UnitsApplication.smallUnit),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                painter = painterResource(id = R.drawable.ic_left_arrow),
                contentDescription = null,
                tint = BlackColor80,
                modifier = Modifier.noRippleClickable { navController.popBackStack() }
            )
            SpacerHorizontalSmall()
            Text(
                text = stringResource(R.string.edit_account_information),
                fontSize = UnitsApplication.mediumFontSize,
                color = BlackColor80,
                fontWeight = FontWeight.SemiBold
            )
        }

        SpacerVerticalMedium()

        InputField(
            value = state.subjectMessage,
            onValueChange = { viewModel.onWriteSubject(it) },
            placeholderText = "الموضوع"
        )

        InputField(
            value = state.bodyMessage,
            onValueChange = { viewModel.onWriteBodyMessage(it) },
            placeholderText = "نص طلب المساعدة"
        )

        PrimaryButton(
            textButton = "ارسال",
            onClick = { viewModel.onClickTheSendButton(navController)},
            isLoading = false
        )
    }
}